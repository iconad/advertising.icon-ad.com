export const ChooseSite = () => import('../../components/ChooseSite.vue' /* webpackChunkName: "components/choose-site" */).then(c => wrapFunctional(c.default || c))
export const Footer = () => import('../../components/Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const TopNavbar = () => import('../../components/TopNavbar.vue' /* webpackChunkName: "components/top-navbar" */).then(c => wrapFunctional(c.default || c))
export const PlusCover = () => import('../../components/plus/Cover.vue' /* webpackChunkName: "components/plus-cover" */).then(c => wrapFunctional(c.default || c))
export const AssetsBehance = () => import('../../components/assets/Behance.vue' /* webpackChunkName: "components/assets-behance" */).then(c => wrapFunctional(c.default || c))
export const AssetsClose = () => import('../../components/assets/Close.vue' /* webpackChunkName: "components/assets-close" */).then(c => wrapFunctional(c.default || c))
export const AssetsCreativityLines = () => import('../../components/assets/CreativityLines.vue' /* webpackChunkName: "components/assets-creativity-lines" */).then(c => wrapFunctional(c.default || c))
export const AssetsFacebook = () => import('../../components/assets/Facebook.vue' /* webpackChunkName: "components/assets-facebook" */).then(c => wrapFunctional(c.default || c))
export const AssetsIconPlus = () => import('../../components/assets/IconPlus.vue' /* webpackChunkName: "components/assets-icon-plus" */).then(c => wrapFunctional(c.default || c))
export const AssetsLayoutOne = () => import('../../components/assets/LayoutOne.vue' /* webpackChunkName: "components/assets-layout-one" */).then(c => wrapFunctional(c.default || c))
export const AssetsLinkedIn = () => import('../../components/assets/LinkedIn.vue' /* webpackChunkName: "components/assets-linked-in" */).then(c => wrapFunctional(c.default || c))
export const AssetsLock = () => import('../../components/assets/Lock.vue' /* webpackChunkName: "components/assets-lock" */).then(c => wrapFunctional(c.default || c))
export const AssetsLogo = () => import('../../components/assets/Logo.vue' /* webpackChunkName: "components/assets-logo" */).then(c => wrapFunctional(c.default || c))
export const AssetsLogoAdWhite = () => import('../../components/assets/LogoAdWhite.vue' /* webpackChunkName: "components/assets-logo-ad-white" */).then(c => wrapFunctional(c.default || c))
export const AssetsLogoBrandSoon = () => import('../../components/assets/LogoBrandSoon.vue' /* webpackChunkName: "components/assets-logo-brand-soon" */).then(c => wrapFunctional(c.default || c))
export const AssetsLogoDigitalWhite = () => import('../../components/assets/LogoDigitalWhite.vue' /* webpackChunkName: "components/assets-logo-digital-white" */).then(c => wrapFunctional(c.default || c))
export const AssetsLogoPlusSoon = () => import('../../components/assets/LogoPlusSoon.vue' /* webpackChunkName: "components/assets-logo-plus-soon" */).then(c => wrapFunctional(c.default || c))
export const AssetsLogoWhite = () => import('../../components/assets/LogoWhite.vue' /* webpackChunkName: "components/assets-logo-white" */).then(c => wrapFunctional(c.default || c))
export const AssetsMenu = () => import('../../components/assets/Menu.vue' /* webpackChunkName: "components/assets-menu" */).then(c => wrapFunctional(c.default || c))
export const AssetsPinterest = () => import('../../components/assets/Pinterest.vue' /* webpackChunkName: "components/assets-pinterest" */).then(c => wrapFunctional(c.default || c))
export const AssetsPlayButton = () => import('../../components/assets/PlayButton.vue' /* webpackChunkName: "components/assets-play-button" */).then(c => wrapFunctional(c.default || c))
export const AssetsPlayButtonWhite = () => import('../../components/assets/PlayButtonWhite.vue' /* webpackChunkName: "components/assets-play-button-white" */).then(c => wrapFunctional(c.default || c))
export const AssetsRightAngleArrowBlack = () => import('../../components/assets/RightAngleArrowBlack.vue' /* webpackChunkName: "components/assets-right-angle-arrow-black" */).then(c => wrapFunctional(c.default || c))
export const AssetsRightAngleArrowWhite = () => import('../../components/assets/RightAngleArrowWhite.vue' /* webpackChunkName: "components/assets-right-angle-arrow-white" */).then(c => wrapFunctional(c.default || c))
export const AssetsRightArrowWhite = () => import('../../components/assets/RightArrowWhite.vue' /* webpackChunkName: "components/assets-right-arrow-white" */).then(c => wrapFunctional(c.default || c))
export const AssetsVimeo = () => import('../../components/assets/Vimeo.vue' /* webpackChunkName: "components/assets-vimeo" */).then(c => wrapFunctional(c.default || c))
export const FormsCareerForm = () => import('../../components/forms/CareerForm.vue' /* webpackChunkName: "components/forms-career-form" */).then(c => wrapFunctional(c.default || c))
export const FormsContactUs = () => import('../../components/forms/ContactUs.vue' /* webpackChunkName: "components/forms-contact-us" */).then(c => wrapFunctional(c.default || c))
export const FormsForm = () => import('../../components/forms/Form.vue' /* webpackChunkName: "components/forms-form" */).then(c => wrapFunctional(c.default || c))
export const FormsNewsLetter = () => import('../../components/forms/NewsLetter.vue' /* webpackChunkName: "components/forms-news-letter" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingMainNavbar = () => import('../../components/advertising/MainNavbar.vue' /* webpackChunkName: "components/advertising-main-navbar" */).then(c => wrapFunctional(c.default || c))
export const UtilsDemo = () => import('../../components/utils/Demo.vue' /* webpackChunkName: "components/utils-demo" */).then(c => wrapFunctional(c.default || c))
export const UtilsImage = () => import('../../components/utils/Image.vue' /* webpackChunkName: "components/utils-image" */).then(c => wrapFunctional(c.default || c))
export const UtilsProjectImage = () => import('../../components/utils/ProjectImage.vue' /* webpackChunkName: "components/utils-project-image" */).then(c => wrapFunctional(c.default || c))
export const UtilsRainbowBar = () => import('../../components/utils/RainbowBar.vue' /* webpackChunkName: "components/utils-rainbow-bar" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingAboutProject = () => import('../../components/advertising/about/Project.vue' /* webpackChunkName: "components/advertising-about-project" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingAboutProjects = () => import('../../components/advertising/about/Projects.vue' /* webpackChunkName: "components/advertising-about-projects" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingAboutRainbowMap = () => import('../../components/advertising/about/RainbowMap.vue' /* webpackChunkName: "components/advertising-about-rainbow-map" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingClientClients = () => import('../../components/advertising/client/Clients.vue' /* webpackChunkName: "components/advertising-client-clients" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingExpertiseExpertises = () => import('../../components/advertising/expertise/Expertises.vue' /* webpackChunkName: "components/advertising-expertise-expertises" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingExpertiseList = () => import('../../components/advertising/expertise/List.vue' /* webpackChunkName: "components/advertising-expertise-list" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingExpertiseListItem = () => import('../../components/advertising/expertise/ListItem.vue' /* webpackChunkName: "components/advertising-expertise-list-item" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingFrontCover = () => import('../../components/advertising/front/Cover.vue' /* webpackChunkName: "components/advertising-front-cover" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingFrontCoverVideo = () => import('../../components/advertising/front/CoverVideo.vue' /* webpackChunkName: "components/advertising-front-cover-video" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingProjectGetRandomProject = () => import('../../components/advertising/project/GetRandomProject.vue' /* webpackChunkName: "components/advertising-project-get-random-project" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingProject = () => import('../../components/advertising/project/Project.vue' /* webpackChunkName: "components/advertising-project" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingProjectAsset = () => import('../../components/advertising/project/ProjectAsset.vue' /* webpackChunkName: "components/advertising-project-asset" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingProjectAssets = () => import('../../components/advertising/project/ProjectAssets.vue' /* webpackChunkName: "components/advertising-project-assets" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingProjectPageCover = () => import('../../components/advertising/project/ProjectPageCover.vue' /* webpackChunkName: "components/advertising-project-page-cover" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingProjectProjects = () => import('../../components/advertising/project/Projects.vue' /* webpackChunkName: "components/advertising-project-projects" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingProjectRelatedProjects = () => import('../../components/advertising/project/RelatedProjects.vue' /* webpackChunkName: "components/advertising-project-related-projects" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingProjectSelectedProjectsCarousel = () => import('../../components/advertising/project/SelectedProjectsCarousel.vue' /* webpackChunkName: "components/advertising-project-selected-projects-carousel" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingServicesCoverVideo = () => import('../../components/advertising/services/CoverVideo.vue' /* webpackChunkName: "components/advertising-services-cover-video" */).then(c => wrapFunctional(c.default || c))
export const AdvertisingIconersCarousel = () => import('../../components/advertising/iconers/Carousel.vue' /* webpackChunkName: "components/advertising-iconers-carousel" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
