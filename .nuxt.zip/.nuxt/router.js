import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5ad264c4 = () => interopDefault(import('../pages/about.vue' /* webpackChunkName: "pages/about" */))
const _b6f229d0 = () => interopDefault(import('../pages/coming-soon.vue' /* webpackChunkName: "pages/coming-soon" */))
const _7ff8f22a = () => interopDefault(import('../pages/contact-us.vue' /* webpackChunkName: "pages/contact-us" */))
const _1f9d942c = () => interopDefault(import('../pages/digital/index.vue' /* webpackChunkName: "pages/digital/index" */))
const _4fd3037f = () => interopDefault(import('../pages/icon-plus.vue' /* webpackChunkName: "pages/icon-plus" */))
const _3214513c = () => interopDefault(import('../pages/projects/index.vue' /* webpackChunkName: "pages/projects/index" */))
const _5636bc20 = () => interopDefault(import('../pages/services/index.vue' /* webpackChunkName: "pages/services/index" */))
const _20c1fe66 = () => interopDefault(import('../pages/thank-you.vue' /* webpackChunkName: "pages/thank-you" */))
const _a1437882 = () => interopDefault(import('../pages/digital/one-two.vue' /* webpackChunkName: "pages/digital/one-two" */))
const _5c77af60 = () => interopDefault(import('../pages/projects/_project.vue' /* webpackChunkName: "pages/projects/_project" */))
const _1b62af3a = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _5ad264c4,
    name: "about"
  }, {
    path: "/coming-soon",
    component: _b6f229d0,
    name: "coming-soon"
  }, {
    path: "/contact-us",
    component: _7ff8f22a,
    name: "contact-us"
  }, {
    path: "/digital",
    component: _1f9d942c,
    name: "digital"
  }, {
    path: "/icon-plus",
    component: _4fd3037f,
    name: "icon-plus"
  }, {
    path: "/projects",
    component: _3214513c,
    name: "projects"
  }, {
    path: "/services",
    component: _5636bc20,
    name: "services"
  }, {
    path: "/thank-you",
    component: _20c1fe66,
    name: "thank-you"
  }, {
    path: "/digital/one-two",
    component: _a1437882,
    name: "digital-one-two"
  }, {
    path: "/projects/:project",
    component: _5c77af60,
    name: "projects-project"
  }, {
    path: "/",
    component: _1b62af3a,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
